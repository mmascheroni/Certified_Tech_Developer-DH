public class EmpleadoPorHora extends Empleado {

    public EmpleadoPorHora(String nombre, String apellido, double salario){
        this.setNombre(nombre);
        this.apellido = apellido;
        this.salario = salario;
    }

    public void cobrarSueldo(int horasTrabajadas){
        double sueldoFinal = horasTrabajadas * this.salario;
        System.out.println("El salario final es: " + sueldoFinal);
    }
}
