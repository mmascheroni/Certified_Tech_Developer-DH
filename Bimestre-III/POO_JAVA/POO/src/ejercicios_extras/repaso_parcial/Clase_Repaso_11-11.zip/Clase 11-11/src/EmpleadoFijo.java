public class EmpleadoFijo extends Empleado {

    public EmpleadoFijo(String nombre, String apellido, double salario){
        this.setNombre(nombre);
        this.apellido = apellido;
        this.salario = salario;
    }

    public void cobrarSueldo(int horasTrabajadas){
        System.out.println("El salario final es: " + this.salario);
    }

    @Override
    public void imprimirNombreyApellido() {
        System.out.println("Hola, soy un empleado fijo \n Mi nombre es " + this.getNombre() + " y mi apellido " + this.apellido);
    }
}
