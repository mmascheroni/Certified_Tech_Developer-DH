public class Main {

    public static void main(String[] args) {

        EmpleadoFijo empleadoFijo = new EmpleadoFijo("Jose", "Perez", 80000);

        empleadoFijo.imprimirNombreyApellido();
    }
}
