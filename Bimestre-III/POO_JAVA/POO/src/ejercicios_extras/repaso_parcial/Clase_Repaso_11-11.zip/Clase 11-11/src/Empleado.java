public abstract class Empleado {

    private String nombre;
    protected String apellido;
    protected double salario;

    public abstract void cobrarSueldo(int horasTrabajadas);

    public void imprimirNombreyApellido() {
        System.out.println("Mi nombre es " + this.nombre + " y mi apellido " + this.apellido);
    }

    @Override
    public String toString() {
        return "Empleado{" +
                "nombre='" + nombre + '\'' +
                ", apellido='" + apellido + '\'' +
                ", salario=" + salario +
                '}';
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }
}
