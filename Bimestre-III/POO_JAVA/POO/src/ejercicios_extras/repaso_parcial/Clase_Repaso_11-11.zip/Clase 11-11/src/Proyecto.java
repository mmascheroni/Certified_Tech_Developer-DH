import java.util.ArrayList;

public class Proyecto {

    private String nombre;
    private int codigoNumerico;
    private double cantidadHorasHombre;
    private ArrayList<Empleado> empleados;
    private ArrayList<String> tareas;

    public Proyecto(String nombre, int codigo, double cant) {
        this.nombre = nombre;
        this.codigoNumerico = codigo;
        this.cantidadHorasHombre = cant;
        this.empleados = new ArrayList<>();
        this.tareas = new ArrayList<>();
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCodigoNumerico() {
        return codigoNumerico;
    }

    public void setCodigoNumerico(int codigoNumerico) {
        this.codigoNumerico = codigoNumerico;
    }

    public double getCantidadHorasHombre() {
        return cantidadHorasHombre;
    }

    public void setCantidadHorasHombre(double cantidadHorasHombre) {
        this.cantidadHorasHombre = cantidadHorasHombre;
    }

    public ArrayList<Empleado> getEmpleados() {
        return empleados;
    }

    public void setEmpleados(ArrayList<Empleado> empleados) {
        this.empleados = empleados;
    }

    public ArrayList<String> getTareas() {
        return tareas;
    }

    public void setTareas(ArrayList<String> tareas) {
        this.tareas = tareas;
    }
}
